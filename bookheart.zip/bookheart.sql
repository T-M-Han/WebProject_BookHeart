-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2024 at 03:38 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookheart`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlist`
--

CREATE TABLE `adminlist` (
  `id` int(11) NOT NULL,
  `adminname` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminlist`
--

INSERT INTO `adminlist` (`id`, `adminname`, `password`) VALUES
(1, 'admin1', 'Admin001'),
(2, 'admin2', 'Admin002');

-- --------------------------------------------------------

--
-- Table structure for table `booklist`
--

CREATE TABLE `booklist` (
  `bookid` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `bookname` varchar(100) NOT NULL,
  `author` varchar(50) NOT NULL,
  `genre` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booklist`
--

INSERT INTO `booklist` (`bookid`, `image`, `bookname`, `author`, `genre`, `date`, `description`, `price`) VALUES
(1, '../Images/book1.jpg', 'Pride and Prejudice', 'Jane Austen', 'Romantic fiction, Social commentary', '1813-03-02', '\r\n\"Pride and Prejudice\" is a timeless classic written by Jane Austen. Set in early 19th-century England, the novel follows the headstrong and intelligent Elizabeth Bennet as she navigates societal expectations, love, and family dynamics. The story revolves around Elizabeth\'s evolving relationship with the proud Mr. Darcy, exploring themes of class, manners, and personal growth. Austen\'s keen observations, witty dialogue, and insightful commentary on social norms make \"Pride and Prejudice\" a beloved work that continues to resonate with readers worldwide.', 15.99),
(2, '../Images/book2.jpg', 'Leave the World Behind', 'Rumaan Alam', 'Fiction, Thriller', '2020-10-06', '\"Leave the World Behind\" is a thought-provoking novel written by Rumaan Alam. In this suspenseful and timely narrative, a vacationing family\'s idyllic retreat is disrupted when an older couple claiming to be the homeowners arrive with unsettling news. As the story unfolds, it delves into themes of race, privilege, and the fragility of modern life. Alam skillfully builds tension and explores the complexities of human relationships, leaving readers questioning societal norms and pondering the unpredictable nature of our world.', 17.25),
(3, '../Images/book3.png', 'Rich Dad Poor Dad', 'Robert T. Kiyosaki', 'Personal finance, Self-help', '2000-04-01', '\"Rich Dad Poor Dad\" is a personal finance classic written by Robert T. Kiyosaki. The book contrasts the financial philosophies and practices of Kiyosaki\'s biological father (referred to as \"Poor Dad\") and the father of his childhood best friend (referred to as \"Rich Dad\"). It imparts valuable lessons about money, investing, and wealth-building. Kiyosaki emphasizes the importance of financial education, assets, and entrepreneurship in achieving financial success. The book has had a significant impact, inspiring readers to rethink their approach to money and consider alternative paths to financial independence.', 16.85),
(4, '../Images/book4.jpg', 'Becoming', 'Michelle Obama', 'Memoir', '2018-11-13', '\"Becoming\" is a memoir by Michelle Obama, the former First Lady of the United States. In this compelling autobiography, Obama shares her personal journey from her childhood in Chicago to her experiences as the First Lady. The book explores her values, struggles, and triumphs, providing insight into her role as a wife, mother, and public figure. \"Becoming\" is not only a reflection on her life but also an inspiring narrative that encourages readers to embrace their own stories and aspirations while navigating challenges and making a positive impact.', 16),
(5, '../Images/book5.jpg', 'Four Treasures of the Sky', 'Jenny Tinghui Zhang', 'Historical Fiction', '2022-04-05', '“Brilliant and devastating, Four Treasures of the Sky tells the story of Daiyu, who is brought to America against her will and forced to hide who she is even as she grows into her true self. Weaving together myth and history, Zhang\'s work is both timeless and utterly necessary right now.”', 16.99),
(6, '../Images/book6.jpg', 'The River of Lost Footsteps', 'Thant Myint-U', 'Non-fiction, History, Memoir', '2006-06-01', '\"The River of Lost Footsteps: A Personal History of Burma\" is a book written by Thant Myint-U. Published in 2006, the book is both a personal memoir and a historical exploration of Myanmar (Burma). Thant Myint-U, a historian and grandson of former UN Secretary-General U Thant, provides insights into Myanmar\'s tumultuous past, including colonial rule, independence, military dictatorship, and the struggle for democracy.', 13.99),
(7, '../Images/book7.png', 'A Teaspoon of Earth and Sea', 'Dina Nayeri', 'Fiction, Coming-of-Age', '2013-02-12', '\"A Teaspoon of Earth and Sea\" is a novel written by Dina Nayeri. Published in 2013, the book is a coming-of-age story set in post-revolutionary Iran. It follows the life of a young girl named Saba Hafezi, who, after witnessing her twin sister\'s mysterious disappearance, grows up in the turbulent atmosphere of Iran during the Islamic Revolution.', 14.99),
(8, '../Images/book8.jpg', 'The Witches', 'Roald Dahl', 'Children fiction, Fantasy', '1983-12-30', '\"The Witches\" is a children\'s fantasy novel written by Roald Dahl. It was first published in 1983. The story follows a young boy who, after the loss of his parents, goes to live with his grandmother. The grandmother informs him about the existence of witches who despise children and have a plan to turn them all into mice.', 12),
(9, '../Images/book9.jpg', 'Get in Trouble ', 'Kelly Link', 'Short Stories, Fantasy, Fiction', '2015-02-03', '\"Get in Trouble\" is a collection of enchanting and inventive short stories by Kelly Link. Blurring the lines between fantasy, magical realism, and contemporary fiction, Links narratives are a blend of the surreal and the ordinary. The stories explore themes of love, identity, and the unexpected, often featuring characters grappling with the supernatural in their everyday lives. Links prose is both lyrical and thought-provoking, creating a literary experience that is both playful and profound. \"Get in Trouble\" showcases the authors mastery of the short story form, offering readers a delightful and imaginative journey into the unexpected.', 12.25),
(10, '../Images/book10.jpg', 'City of Orange', 'David Yoon', ' Science fiction,  Psychological fiction', '2020-05-04', 'A man who can not remember his own name wakes up in an apocalyptic landscape, injured and alone. He has vague memories of life before, but he can\'t see it clearly and can\'t grasp how his current situation came to be. He must learn to survive by finding sources of water and foraging for food.', 13.5),
(11, '../Images/book11.jpg', 'The Godfather', 'Mario Puzo', 'Crime fiction, Mafia', '1969-03-10', 'Mario Puzo\'s \"The Godfather\" is a timeless crime novel that delves into the powerful and intricate world of the Mafia. Centered around the Corleone family, the story explores themes of power, honor, and the consequences of a life steeped in crime. With memorable characters like Vito Corleone and his sons, Puzo weaves a narrative that blends family drama with organized crime, creating an iconic portrayal of the American Mafia. \"The Godfather\" has left an indelible mark on popular culture, inspiring films, and remains a classic exploration of the complexities of power and loyalty in the criminal underworld.', 14.5),
(12, '../Images/book12.jpg', 'Follow Me to the Ground', 'Sue Rainsford', 'Fiction, Magical Realism', '2020-01-21', 'Sue Rainsford\'s \"Follow Me to the Ground\" is a mesmerizing exploration of the surreal and the supernatural. The novel revolves around Ada, a mysterious, otherworldly healer who can cure ailments by pulling sickness from the bodies of her village neighbors. As her abilities defy understanding, Ada grapples with her own identity and the complexities of love. Rainsford\'s prose is evocative and haunting, blending magical realism with elements of folklore. \"Follow Me to the Ground\" offers a unique and atmospheric reading experience, inviting readers into a world where the boundaries between the natural and the supernatural are beautifully blurred.', 13.99),
(13, '../Images/book13.jpg', 'Liar\'s Dictionary', 'Eley Williams', 'Fiction, Literary Fiction, Comedy', '2022-01-18', 'In \"Liar\'s Dictionary,\" Eley Williams crafts a delightful and clever narrative that weaves together two distinct stories. Set in different time periods, the novel follows Peter Winceworth, a lexicographer in Victorian-era London, and Mallory, a young intern at a present-day dictionary publishing house. The narrative intertwines wordplay, linguistic puzzles, and comedic elements, exploring the nuances of language and human connection. Williams\' witty prose and inventive storytelling make \"Liar\'s Dictionary\" a unique and engaging reading experience, celebrating the beauty and idiosyncrasies of the English language while unraveling the mysteries of the characters\' lives.', 12.99),
(14, '../Images/book14.jpeg', 'Under The Dragon', 'Rory MacLean', 'Travel literature', '2008-09-15', 'Twenty-five years ago the Burmese people rose up against their military government. The unarmed demonstrators were cut down, leaving more than 5,000 dead. In \'Under the Dragon\', Rory MacLean meets the victims and perpetrators of the uprising, unraveling a paradox of selfless generosity and sinister greed', 13.25),
(15, '../Images/book15.jpg', 'British Burma and Its People', 'Westphalia Press', 'Travel literature', '2019-09-10', 'In 1879, Nature: The International Journal of Science, offered this review of this work:\"This book is offered as the result of thirteen years\' experience derived from close intercourse, both officially and privately, with the people of Burma during that period.', 15.7),
(16, '../Images/book16.jpg', 'The Paper Palace', 'Miranda Cowley Heller', ' Romance novel, Psychological Fiction, Domestic Fi', '2021-07-02', '\'A deeply emotional love story that follows one day in the life of Elle Bishop as she navigates the unravelling of secrets, lies and a very complex love triangle\' REESE WITHERSPOON\'Glorious and gorgeous.', 15.99),
(17, '../Images/book17.jpg', 'How to Calm Your Mind?', 'Chris Bailey', 'Reality', '2022-12-27', 'A toolkit of accessible, science-backed strategies that reveal that the path to a less anxious life, and even greater productivity, runs directly through calm.', 14.5),
(18, '../Images/book18.jpg', 'Take My Hand', 'Dolen Perkins-Valdez', 'Historical Fiction', '2022-04-12', 'AS SEEN ON BBC2 BETWEEN THE COVERSMontgomery, Alabama. 1973. Fresh out of nursing school, Civil Townsend has big plans to make a difference in her community.', 16.25),
(19, '../Images/book19.jpg', 'To Kill A Mocking Bird', 'Harper Lee', 'Novel, Bildungsroman, Southern Gothic, Domestic Fi', '1960-07-11', 'To Kill a Mockingbird is a novel by the American author Harper Lee. It was published in June 1960 and became instantly successful. In the United States, it is widely read in high schools and middle schools.', 13.5),
(20, '../Images/book20.jpg', 'Where Forest Meets the Stars', 'Glendy Vanderah', 'Domestic Fiction', '2019-03-01', '\"Where the Forest Meets the Stars\" is a captivating novel by Glendy Vanderah that intertwines mystery, grief, and the magic of human connection. Jo Teale, a grief-stricken graduate student, encounters an enigmatic child claiming to be an alien. As they embark on a journey to witness the arrival of an extraterrestrial, they navigate healing, love, and the profound impact of the unexplainable. Vanderah\'s lyrical prose weaves a poignant tale that explores the depths of loss and the transformative power of hope in unexpected places.', 12.99);

-- --------------------------------------------------------

--
-- Table structure for table `commentlist`
--

CREATE TABLE `commentlist` (
  `commentid` int(11) NOT NULL,
  `Cmemberid` int(11) NOT NULL,
  `membername` varchar(50) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `commentlist`
--

INSERT INTO `commentlist` (`commentid`, `Cmemberid`, `membername`, `comment`) VALUES
(1, 1, 'Thaw Myo Han', 'BookHeart\'s online haven is a bookworm\'s delight. Navigating through its virtual shelves is a seamless experience, with a diverse array of titles catering to various tastes. The user-friendly interface makes book exploration a joy, and the efficient search feature ensures you find your literary desires with ease. BookHeart\'s commitment to reader engagement shines through its online book club and author spotlights. The website\'s seamless functionality and dedication to community make it a standout destination for book enthusiasts seeking a digital sanctuary. BookHeart — where the love for literature finds its online home.');

-- --------------------------------------------------------

--
-- Table structure for table `memberlist`
--

CREATE TABLE `memberlist` (
  `memberid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `memberlist`
--

INSERT INTO `memberlist` (`memberid`, `name`, `age`, `address`, `phone`, `email`, `username`, `password`) VALUES
(1, 'Thaw Myo Han', 20, 'MarLarMying(8)street, Hlaing, Yangon', '09253034566', 'thawmyohan@gmail.com', 'Thaw', 'Tmh001'),
(2, 'Wai Yan Kyaw', 19, 'Bahan, Yangon', '09253029573', 'waiyankyaw@gmail.com', 'Wai', 'Wyk002'),
(5, 'Zaw Thet Naing', 19, 'South Dagon', '09253074926', 'zawthetnaing@gmail.com', 'Zaw', 'Zaw003');

-- --------------------------------------------------------

--
-- Table structure for table `morderlist`
--

CREATE TABLE `morderlist` (
  `Morderid` int(11) NOT NULL,
  `date` date NOT NULL,
  `Mbookid` int(11) NOT NULL,
  `memberid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `morderlist`
--

INSERT INTO `morderlist` (`Morderid`, `date`, `Mbookid`, `memberid`, `name`, `age`, `address`, `phone`, `email`) VALUES
(1, '2024-01-30', 5, 1, 'Thaw Myo Han', 20, 'MarLarMying(8)street, Hlaing, Yangon', '09253034566', 'thawmyohan@gmail.com'),
(4, '2024-01-30', 14, 1, 'Thaw Myo Han', 20, 'MarLarMying(8)street, Hlaing, Yangon', '09253034566', 'thawmyohan@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `orderlist`
--

CREATE TABLE `orderlist` (
  `orderid` int(11) NOT NULL,
  `date` date NOT NULL,
  `Obookid` int(11) NOT NULL,
  `customername` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderlist`
--

INSERT INTO `orderlist` (`orderid`, `date`, `Obookid`, `customername`, `age`, `address`, `phone`, `email`) VALUES
(1, '2024-01-30', 7, 'hsu', 19, 'Insein,Yangon', '09405169123', 'hsu@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlist`
--
ALTER TABLE `adminlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booklist`
--
ALTER TABLE `booklist`
  ADD PRIMARY KEY (`bookid`);

--
-- Indexes for table `commentlist`
--
ALTER TABLE `commentlist`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `Cmemberid` (`Cmemberid`);

--
-- Indexes for table `memberlist`
--
ALTER TABLE `memberlist`
  ADD PRIMARY KEY (`memberid`);

--
-- Indexes for table `morderlist`
--
ALTER TABLE `morderlist`
  ADD PRIMARY KEY (`Morderid`),
  ADD KEY `Mbookid` (`Mbookid`),
  ADD KEY `memberid` (`memberid`);

--
-- Indexes for table `orderlist`
--
ALTER TABLE `orderlist`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `Obookid` (`Obookid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminlist`
--
ALTER TABLE `adminlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `booklist`
--
ALTER TABLE `booklist`
  MODIFY `bookid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `commentlist`
--
ALTER TABLE `commentlist`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `memberlist`
--
ALTER TABLE `memberlist`
  MODIFY `memberid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `morderlist`
--
ALTER TABLE `morderlist`
  MODIFY `Morderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orderlist`
--
ALTER TABLE `orderlist`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `commentlist`
--
ALTER TABLE `commentlist`
  ADD CONSTRAINT `commentlist_ibfk_1` FOREIGN KEY (`Cmemberid`) REFERENCES `memberlist` (`memberid`);

--
-- Constraints for table `morderlist`
--
ALTER TABLE `morderlist`
  ADD CONSTRAINT `morderlist_ibfk_1` FOREIGN KEY (`Mbookid`) REFERENCES `booklist` (`bookid`),
  ADD CONSTRAINT `morderlist_ibfk_2` FOREIGN KEY (`memberid`) REFERENCES `memberlist` (`memberid`);

--
-- Constraints for table `orderlist`
--
ALTER TABLE `orderlist`
  ADD CONSTRAINT `orderlist_ibfk_1` FOREIGN KEY (`Obookid`) REFERENCES `booklist` (`bookid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
